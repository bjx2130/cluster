package com.sh.dao;

public interface FlushModeDao {
	
	void auto();
	
	void commit();
	
	void munul();
	
}
