package com.sm.service;

public interface BatchDao {	
	
	public void insert() throws Exception;
}

