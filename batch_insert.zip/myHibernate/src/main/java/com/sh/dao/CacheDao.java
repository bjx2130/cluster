package com.sh.dao;

public interface CacheDao {
	
	
	
	void secondLevel();
	
	
	void queryCache();
}
