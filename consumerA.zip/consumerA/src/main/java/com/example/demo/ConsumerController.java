package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@RestController
public class ConsumerController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@HystrixCommand(fallbackMethod="fallBack")
	@RequestMapping("/ribbon-consumer")
    public String consumer() {
        return this.restTemplate.getForEntity("http://SERVICE-A/hello", String.class).getBody();
    }
	
	
	public String fallBack(){
		return "erro";
	}
	
	
	
}
